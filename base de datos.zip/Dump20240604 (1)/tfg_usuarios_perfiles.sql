-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tfg
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `usuarios_perfiles`
--

DROP TABLE IF EXISTS `usuarios_perfiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios_perfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contraseña` varchar(255) DEFAULT NULL,
  `plan` varchar(50) DEFAULT NULL,
  `ubicacion` varchar(100) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios_perfiles`
--

LOCK TABLES `usuarios_perfiles` WRITE;
/*!40000 ALTER TABLE `usuarios_perfiles` DISABLE KEYS */;
INSERT INTO `usuarios_perfiles` VALUES (1,'Hola','hola@educantabria.es','$2y$10$5zUTwLAl5zgN7n1oSNmBqeGk/NK6t/BrpBoLUJzqI0LleQRpsh4ei',NULL,NULL,NULL),(2,'David Fernandez','dfernandezv04@educantabria.es','$2y$10$TWenzsyiqdz.sWvt6Ak6IO1lZ7EKckbml1ud7ELdx4UKQZkVyNdHG','Basic','Santander','2024-03-05'),(3,'PRUEBA1','JoseLuis2@gmail.com','$2y$10$IrarjIS0pB8DuNwhG5pJE.7CXEo/XPlOpDn5w/zhdWrG/5joYXIry','Diamond','Santander','2024-03-27'),(4,'David','dafevi03@gmail.com','$2y$10$HYCzor6SZGt1OUvZX0aZQuVb4kMaeciWLfwUdJOBVKz9i92ofR6R6','Gold','Mortera','2024-03-15'),(5,'David','dafevi@gmail.com','$2y$10$7eNQvF7Lv7LZv6K8aCH/peET7jSXls8mb6x2WO0g6BdD8mzLDq9ku',NULL,'Mortera','2024-03-13'),(6,'David','dafevi07@gmail.com','$2y$10$zR87J3ntPXC1.3leoRnJMe9l29xT9FzTjhpnjVbfLErifFkv0Xb.6',NULL,NULL,NULL),(7,'Joze','jose1@gmail.com','$2y$10$LRm0WVA8syOaH0NYkBIJwOQyfPDlZGiixOAoxBjyt28FX13O3nq7O',NULL,NULL,NULL),(8,'Mateo','mateo1@gmail.com','$2y$10$1QFLle4Kj0RFygbzftrHnOw5j8Ne8OrmjCnY1FjKKqybt46Sq6PFC',NULL,NULL,NULL);
/*!40000 ALTER TABLE `usuarios_perfiles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-04 17:15:14
