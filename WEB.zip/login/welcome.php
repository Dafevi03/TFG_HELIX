<?php
// Datos de conexión a la base de datos
$servername = "localhost:3308";
$username = "david";
$password = "david";
$dbname = "tfg";

// Iniciar sesión (asegúrate de haber iniciado sesión antes de ejecutar este código)
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    echo "Usuario no autenticado. Por favor, inicie sesión.";
    exit; // Salir del script si el usuario no está autenticado
}

// Obtener el ID del usuario actualmente autenticado
$usuario_id = $_SESSION['user_id'];

$usuario_nombre = '';
$usuario_email = '';
$usuario_ubicacion = '';
$usuario_fecha_nacimiento = '';

try {
    // Crear una nueva conexión PDO
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    
    // Configurar el modo de error de PDO para lanzar excepciones
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Preparar la consulta SQL para obtener los datos del usuario actual
    $stmt = $conn->prepare("SELECT nombre, email FROM usuarios_perfiles WHERE id = :usuario_id");
    
    // Bind parameters
    $stmt->bindParam(':usuario_id', $usuario_id);
    
    // Ejecutar la consulta
    $stmt->execute();
    
    // Comprobar si se encontraron resultados
    if ($stmt->rowCount() > 0) {
        // Obtener los datos del usuario
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Almacenar los datos del usuario en variables
        $usuario_nombre = $row["nombre"] ?? '';
        $usuario_email = $row["email"] ?? '';
    } else {
        echo "No se encontraron resultados para el usuario con ID: $usuario_id";
        exit; // Salir del script si no se encontraron resultados
    }
} catch(PDOException $e) {
    echo "Error de conexión: " . $e->getMessage();
    exit; // Salir del script en caso de error
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/3.5.0/remixicon.min.css">
    <link rel="stylesheet" href="stylewelcome.css">
    <title>TFG</title>
    <style>
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #323232;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
            top: 106px; 
            border-radius: 4px; 
            flex-direction: column; 
            border: 1px solid #fff; 
        }

        .user-menu:hover .dropdown-content {
            display: flex; 
        }

        .user-icon {
            background-color: #1d4ed8; 
            color: white; 
            border: none;
            border-radius: 50%; 
            width: 50px; 
            height: 50px; 
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .dropdown-content a {
            padding: 12px 16px; 
            text-decoration: none;
            color: white; 
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #1e40af; 
        }

        .contact {
            background-color: #18181B;
            padding: 5rem 2rem;
        }

        .contact .container {
            max-width: 500px; 
            margin: auto;
            background-color: #27272a;
            padding: 2rem;
            border-radius: 15px;
            border: 2px solid transparent;
            transition: all 0.3s ease;
        }

        .contact .container:hover {
            background-color: #323232;
            border-color: #fff;
        }

        .contact form {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .contact form label {
            color: #ccc;
            margin-bottom: 0.5rem;
        }

        .contact form input,
        .contact form textarea {
            width: 100%;
            padding: 0.75rem;
            background-color: #18181B;
            border: 2px solid #27272a;
            border-radius: 5px;
            color: #fff;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
        }

        .contact form input:focus,
        .contact form textarea:focus {
            border-color: #1d4ed8;
        }

        .contact form button {
            padding: 1rem 2rem;
            background-color: #1d4ed8;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .contact form button:hover {
            background-color: #1e40af;
        }
    </style>
</head>

<body>
    <nav>
        <div class="nav-logo">
            <a href="#">
                <img src="/images/logo1.png">
            </a>
        </div>
        <ul class="nav-links">
            <li class="link"><a href="#">Inicio</a></li>
            <li id="link1" class="link"><a href="#">Producto</a></li>
            <li id="link2" class="link"><a href="#">Precio</a></li>
            <li id="link4" class="link"><a href="#contacto">Contacto</a></li>
            <li id="link5" class="link"><a href="#footer">Sobre nosotros</a></li>
            <li id="link6" class="link"><a href="#">Administrador</a></li>
        </ul>
        <a href="/login/cerrarses.php" class="btn">Cerrar sesión</a>
    </nav>

    <header class="container">
        <div class="content">
            <span class="blur"></span>
            <span class="blur"></span>
            <h4>GESTIONA TU INVENTARIO COMO UN PRO</h4>
            <H1>Hola, somos <span>JD</span>, estudiantes de ASIR</H1>
            <p>
                Tenemos como objetivo desarrollar un sistema de inventario y diagnóstico de hardware para una red LAN, con
                enfoque en la monitorización de puestos de trabajo.
            </p>
            <a href="#contacto" class="btn">Contactanos</a>
        </div>
        <div class="image">
            <img src="/images/header.png">
        </div>
    </header>

    <section class="container">
        <h2 class="header">NUESTRO PRODUCTO</h2>
        <div class="features">
            <div class="card">
                <span><i class="ri-money-dollar-box-line"></i></span>
                <h4>Diagnostico hardware</h4>
                <p>
                    Tendrás un diagnóstico hardware de todos los equipos.
                </p>
                
            </div>
            <div class="card">
                <span><i class="ri-bug-line"></i></span>
                <h4>Información de la red</h4>
                <p>
                    Te informará de si tu red tiene algún fallo.
                </p>
                
            </div>
            <div class="card">
                <span><i class="ri-history-line"></i></span>
                <h4>Panel de control</h4>
                <p>
                    Se te creará un panel de control personalizado.
                </p>
                
            </div>
            <div class="card">
                <span><i class="ri-shake-hands-line"></i></span>
                <h4>Detección de problemas</h4>
                <p>
                    Añadirá un sistema de detección de problemas a tus dispositivos.
                </p>
                
            </div>
        </div>
    </section>

    <section class="container">
        <h2 class="header">PRECIO DE PLANES</h2>
        <p class="sub-header">
            Los precios varían según el plan que escojas y lo que necesites. Si no estás conforme con ninguno de estos planes puedes ponerte en contacto con nosotros.
        </p>
        <div class="pricing">
            <div class="card">
                <div class="content">
                    <h4>Basic Plan</h4>
                    <h3>99€</h3>
                    <p>
                        <i class="ri-checkbox-circle-line"></i>
                        Máximo 5 dispositivos.
                    </p>
                    <p>
                        <i class="ri-checkbox-circle-line"></i>
                        Instalación + inventario.
                    </p>
                </div>
                <a href="#contacto" class="btn">Contactanos</a>
            </div>
            <div class="card">
                <div class="content">
                    <h4>Gold Plan</h4>
                    <h3>399€</h3>
                    <p>
                        <i class="ri-checkbox-circle-line"></i>
                        Máximo 20 dispositivos.
                    </p>
                    <p>
                        <i class="ri-checkbox-circle-line"></i>
                        Instalación + inventario.
                    </p>
                    <p>
                        <i class="ri-checkbox-circle-line"></i>
                        Diagnóstico de hardware.
                    </p>
                </div>
                <a href="#contacto" class="btn">Contactanos</a>
            </div>
            <div class="card">
                <div class="content">
                    <h4>Diamond Plan</h4>
                    <h3>699€</h3>
                    <p>
                        <i class="ri-checkbox-circle-line"></i>
                        Sin límite de dispositivos.
                    </p>
                    <p>
                        <i class="ri-checkbox-circle-line"></i>
                        Instalación + inventario.
                    </p>
                    <p>
                        <i class="ri-checkbox-circle-line"></i>
                        Diagnóstico de hardware.
                    </p>
                    <p>
                        <i class="ri-checkbox-circle-line"></i>
                        Alertas.
                    </p>
                    <p>
                        <i class="ri-checkbox-circle-line"></i>
                        Detección de problemas.
                    </p>
                </div>
                <a href="#contacto" class="btn">Contactanos</a>
            </div>
        </div>
    </section>

    <section id="contacto" class="contact">
    <h2 class="header">CONTACTO</h2>
    <p class="sub-header">
        ¡Cualquier pregunta o duda respecto a nuestros servicios háznosla saber!
    </p>
    <br></br>
    <div class="container">
        <form action="https://formsubmit.co/dafevi03@gmail.com" method="POST" enctype="text/plain">
            <label for="name">Nombre</label>
            <input type="text" id="name" name="name" value="<?php echo $usuario_nombre; ?>" required>
            
            <label for="email">Correo Electrónico</label>
            <input type="email" id="email" name="email" value="<?php echo $usuario_email; ?>" required>
            
            <label for="subject">Asunto</label>
            <input type="text" id="subject" name="subject" required>
            
            <label for="comments">Mensaje</label>
            <textarea id="message" name="comments" rows="6" required></textarea>
            
            <button type="submit">Enviar</button>
            <input type="hidden" name="_next" value="http://localhost/login/welcome.php">
            <input type="hidden" name="_captcha" value="false">
        </form>
    </div>
</section>

    

    <footer id="footer" class="container">
        <span class="blur"></span>
        <span class="blur"></span>
        <div class="column">
            <div class="logo">
                <img src="/images/logo1.png">
            </div>
            <p>
                Aqui podras ver nuestras redes sociales.
            </p>
            <div class="socials">
                <a href="https://www.youtube.com/channel/UC8rNKrqBxJqL9izOOMxBJtw"><i class="ri-youtube-line"></i></a>
                <a href="https://www.instagram.com/willyrex/?hl=es"><i class="ri-instagram-line"></i></a>
                <a href="https://twitter.com/WillyrexYT?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor"><i class="ri-twitter-line"></i></a>
            </div>
        </div>
        <div class="column">
            <h4>Compañia</h4>
            <a href="#">Business</a>
            <a href="#">Partnership</a>
            <a href="#">Network</a>
        </div>
        <div class="column">
            <h4>Sobre nosotros</h4>
            <a href="https://www.rincondelvago.com/">Blogs</a>
            <a href="#">Channels</a>
            <a href="#">Sponsors</a>
        </div>
        <div class="column">
            <h4>Contacto</h4>
            <a href="#contacto">Contactanos</a>
            <a href="#">Politica y privacidad</a>
            <a href="#">Terminos y condiciones</a>
        </div>
    </footer>

    <div class="copyright">
        Copyright © 2023 Helix diagnostics.
    </div>


    <script src="script.js"></script>
</body>
</html>