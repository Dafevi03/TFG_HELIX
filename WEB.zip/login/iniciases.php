<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        // Mostrar una alerta en la pantalla si hay campos vacíos
        header("Location: login.php?error=emptyfields");
        exit();
    } else {
        $servername = "localhost:3308";
        $username = "david";
        $password_db = "david";
        $dbname = "tfg";

        try {
            $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password_db);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Consultar el usuario en la base de datos
            $stmt = $pdo->prepare("SELECT * FROM usuarios_perfiles WHERE email = :email");
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // Verificar la contraseña
                if (password_verify($password, $user['contraseña'])) {
                    // Iniciar sesión y almacenar los datos del usuario en la sesión
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['name'] = $user['nombre'];
                    $_SESSION['email'] = $user['email'];
                    header("Location: welcome.php");
                    exit();
                } else {
                    // Mostrar una alerta en la pantalla si la contraseña es incorrecta
                    header("Location: login.php?error=wrongpassword");
                    exit();
                }
            } else {
                // Mostrar una alerta en la pantalla si el usuario no existe
                header("Location: login.php?error=nouser");
                exit();
            }
        } catch(PDOException $e) {
            // Mostrar mensaje de error en caso de fallo de la base de datos
            echo "Error: " . $e->getMessage();
            exit();
        }
    }
} else {
    // Redirigir al formulario si no se ha enviado el formulario
    header("Location: login.php");
    exit();
}
?>


