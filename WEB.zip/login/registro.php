<?php
session_start();

// Verificar si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoger los datos del formulario
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Verificar si los campos están vacíos
    if (empty($name) || empty($email) || empty($password)) {
        // Redireccionar al formulario con un mensaje de error si hay campos vacíos
        header("Location: login.php?error=emptyfields");
        exit();
    } else {
        // Conectar a la base de datos
        $servername = "localhost:3308";
        $username = "david";
        $password_db = "david";
        $dbname = "tfg";

        try {
            $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password_db);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Verificar si el correo electrónico ya está en uso
            $stmt = $pdo->prepare("SELECT id FROM usuarios_perfiles WHERE email = :email");
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result) {
                // Redireccionar al formulario con un mensaje de error si el correo electrónico ya está en uso
                header("Location: login.php?error=emailtaken");
                exit();
            } else {
                // Insertar el nuevo usuario en la base de datos
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO usuarios_perfiles (nombre, email, contraseña) VALUES (:nombre, :email, :password)");
                $stmt->bindParam(':nombre', $name);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':password', $hashed_password);
                $stmt->execute();

                // Redireccionar al formulario con un mensaje de éxito
                header("Location: login.php?success=registered");
                exit();
            }
        } catch(PDOException $e) {
            // Mostrar mensaje de error en caso de fallo de la base de datos
            echo "Error: " . $e->getMessage();
            exit();
        }
    }
} else {
    // Redireccionar al formulario si no se ha enviado el formulario
    header("Location: login.php");
    exit();
}
?>


