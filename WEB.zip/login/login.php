<?php
session_start(); 
// Verificar si hay mensajes de error en la URL
if (isset($_GET['error'])) {
    $error = $_GET['error'];
    
    // Mostrar alerta según el tipo de error
    switch ($error) {
        case 'emptyfields':
            echo "<script>alert('Por favor, completa todos los campos.');</script>";
            break;
        case 'wrongpassword':
            echo "<script>alert('Contraseña incorrecta.');</script>";
            break;
        case 'nouser':
            echo "<script>alert('El usuario no existe.');</script>";
            break;
        default:
            // Otro manejo de errores si es necesario
            break;
    }
}
// Verificar si hay mensajes de error en la URL
if (isset($_GET['error'])) {
    $error = $_GET['error'];
    
    // Mostrar alerta según el tipo de error
    switch ($error) {
        case 'emailtaken':
            echo "<script>alert('El correo electrónico ya está en uso.');</script>";
            break;
        default:
            // Otro manejo de errores si es necesario
            break;
    }
}

// Verificar si hay un mensaje de éxito en la URL
if (isset($_GET['success']) && $_GET['success'] == 'registered') {
    echo "<script>alert('Registro exitoso. Por favor inicia sesión.');</script>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="stylelogin.css">
    <title>TFG</title>
</head>

<body>

    <div class="container" id="container">
        <div class="form-container sign-up">
            <form action="registro.php" method="POST">
                <h1>Crea una cuenta</h1>
                <span>Crea una nueva cuenta</span>
                <input type="text" name="name" placeholder="Name">
                <input type="email" name="email" placeholder="Email">
                <input type="password" name="password" placeholder="Password">
                <button type="submit" class="btn">Crear cuenta</button>
            </form>
        </div>
        <div class="form-container sign-in">
            <form action="iniciases.php" method="POST"> 
                <h1>Inicia sesión</h1>
                <span>Inicia sesión con tu cuenta</span>
                <input type="email" name="email" placeholder="Email"> 
                <input type="password" name="password" placeholder="Password"> 
                <button type="submit" class="btn" name="login">Inicia sesión</button> 
            </form>
        </div>
        <div class="toggle-container">
            <div class="toggle">
                <div class="toggle-panel toggle-left">
                    <h1>Hola otra vez!</h1>
                    <p>Entra con tu cuenta para acceder a todas las opciones del sitio web</p>
                    <button class="hidden" id="login">Inicia sesión</button>
                </div>
                <div class="toggle-panel toggle-right">
                    <h1>Hola, amigo!</h1>
                    <p>Regístrate para acceder a todas las opciones del sitio web</p>
                    <button class="hidden" id="register">Regístrate</button>
                </div>
            </div>
        </div>
    </div>

    <script src="scriptlogin.js"></script>
</body>

</html>
